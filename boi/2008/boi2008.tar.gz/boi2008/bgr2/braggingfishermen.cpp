/*
TASK: braggingfishermen
LANG: C++
*/
#include <iostream>
using namespace std;

int N, m[6];

bool query(int k)
{
      //cout << m[0] << " " << m[1] << endl;
      if (k == 1)
      {
            for (int i = 0; i < N; i++) if (m[i] != 1) return 0;
            return 1;
      }
      
      if (query(k-1)) return 1;
      
      for (int i = 0; i < N; i++) if ((m[i]%k) == 0)
      {
          m[i] /= k;
          if (query(k-1)) return 1;
          m[i] *= k;
          //break;
      }
      
      return 0;
}

bool queryFAST(int k)
{
      //cout << m[0] << " " << m[1] << endl;
      if (k == 1)
      {
            for (int i = 0; i < N; i++) if (m[i] != 1) return 0;
            return 1;
      }
      
      if (queryFAST(k-1)) return 1;
      
      for (int i = 0; i < N; i++) if ((m[i]%k) == 0)
      {
          m[i] /= k;
          if (queryFAST(k-1)) return 1;
          m[i] *= k;
          break;
      }
      
      return 0;
}

void solve()
{
     for (int i = 0; i < N; i++) cin >> m[i];
     
     bool flag = 0;
     for (int i = 0; i < N; i++) for (int j = i + 1; j < N; j++) 
      if (m[i] > 5000 || (m[i] == m[j] && m[i] == 1)) flag = 1;
     if (flag) cout << "NO" << endl;
     
     if (N <= 3)
     {
         if (query(100)) cout << "YES" << endl;
         else            cout << "NO"  << endl;
     }
     else
     {
         if (queryFAST(100)) cout << "YES" << endl;
         else                cout << "NO" << endl;
     }
}

int main()
{
    //for (int i = 2; i < 100; i++) if (47%i == 0) { cout << i << endl; break; }
    cin >> N;
    int q; cin >> q;
    for (int qq = 0; qq < q; qq++)
     solve();
    return 0;
}
