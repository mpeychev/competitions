/*
TASK: thecure
LANG: C++
*/
#include <iostream>
#include <set>
#define MAX (1<<20)*30000+10
using namespace std;

long long d[1<<20];
int N;
char movereq[128][32], move[128][32];
int t[128], M;

int dijkstra()
{
    memset(d, 16, sizeof(d));
    
    set<pair<int, int> > heap;
    heap.insert(make_pair(0, (1<<N) - 1));
    d[(1<<N) - 1] = 0;
    
    while (!heap.empty())
    {
          int u = (*heap.begin()).second;
          heap.erase(heap.begin());
          
          if (u == 0) return d[u];
          
          //cout << u << ":" << endl;
          for (int i = 0; i < M; i++)
          {
              bool flag = 0;
              for (int j = 0; j < N; j++) 
               if (((((1<<j)&u) >  0) && movereq[i][j] == '-') ||
                   ((((1<<j)&u) == 0) && movereq[i][j] == '+'))
               {
                     flag = 1;
                     break;
               }
             if (flag) continue; 
             
             int next = u;               
             for (int j = 0; j < N; j++)
             {
                 if (move[i][j] == '+') next |= 1<<j;
                 else if (move[i][j] == '-') next &= ~(1<<j);
             }
             //cout << next << endl;
             if (d[u] + t[i] < d[next])
             {
                  if (d[next] < MAX) heap.erase(heap.find(make_pair(d[next], next)));
                  
                  d[next] = d[u] + t[i];
                  heap.insert(make_pair(d[next], next));
             } 
          }
    }
    
    return -1;
}
int main()
{
    cin >> N >> M;
    for (int i = 0; i < M; i++) cin >> t[i] >> movereq[i] >> move[i];
    cout << dijkstra() << endl;
    return 0;
}
