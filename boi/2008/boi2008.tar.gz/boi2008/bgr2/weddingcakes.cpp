/*
TASK: weddingcakes
LANG: C++
*/
#include <stdio.h>
#include <algorithm>
#include <vector>
using namespace std;

int A[100005];
vector< pair<int, int> > S;
int main()
{
    int N;
    scanf("%d", &N);
    
    for (int i = 0; i < N; i++)
     scanf("%d", &A[i]);
    
    A[N] = 1000004;
    sort(A, A + N);
    
    //for (int i = 0; i < N; i++) printf("%d\n", A[i]);
    int cnt = 1;
    int prev = A[0];
    for (int i = 1; i <= N; i++)
    {
        if (A[i] != A[i-1]) 
        {
             S.push_back(make_pair(cnt, prev));
             prev = A[i];
             cnt = 1;
        }
        else cnt++;
    }
    
    sort(S.begin(), S.end());
    
    //for (int i = 0; i < S.size(); i++) printf("%d %d\n", S[i].first, S[i].second);
    
    int N1 = S.back().first;
    vector<int> R[N1];
    int marker = 0;
    
    for (int i = S.size() - 1; i >= 0; i--)
     for (int j = 0; j < S[i].first; j++)
     {
         R[marker++].push_back(S[i].second);
         if (marker == N1) marker = 0;
     }
    printf("%d\n", N1);
    for (int i = N1-1; i >= 0; i--)
    {
         sort(R[i].begin(), R[i].end());
         
         printf("%d", R[i][0]);
         for (int j = 1; j < R[i].size(); j++) printf(" %d", R[i][j]);
         printf("\n");
    }
    
    return 0;
}
