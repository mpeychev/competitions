/*
TASK: laundry
LANG: C++
*/
#include <iostream>
#define MAX 200*300000
using namespace std;
int N, K;
int DP[203][33];
int p[205];

int prec[205][205];

int dp(int n, int k)
{
    if (n == -1) return 0;
    
    int &ret = DP[n][k];
    if (ret != -1) return ret;
    
    ret = MAX;
    if (k == 0)
    {
          int sum = 0;
          for (int j = 0; j <= n; j++)
           sum += p[n+1] - p[j];
          return ret = sum;
    }
    
    for (int i = n; i >= k-1; i--)
    {
        int sum = 0;
        if (n == N-1)
         for (int j = i + 1; j <= n; j++)
          sum += p[j] - p[i];
        else sum = prec[i][n+1];
        
        ret = min(ret, dp(i - 1, k - 1) + sum);
    }
    
    return ret;
}
int main()
{
    memset(DP, -1, sizeof(DP));
    
    cin >> N >> K;
    for (int i = 0; i < N; i++) cin >> p[i];
    p[N] = 200000;
    
    for (int i = 0; i < N; i++)
     for (int j = i + 1; j < N; j++)
      for (int k = i + 1; k < j; k++) 
       prec[i][j] += min(p[k] - p[i], p[j] - p[k]);
    
    cout << dp(N-1, K) << endl;
    
    return 0;
}
