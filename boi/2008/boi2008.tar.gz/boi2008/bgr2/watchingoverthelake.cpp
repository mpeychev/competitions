/*
TASK: watchingoverthelake
LANG: C++
*/
#include <iostream>
#include <math.h>
#define eps 1e-9
using namespace std;

struct point
{
       double x, y;
       point(double _x, double _y):x(_x), y(_y){}
       point(){}
       point operator-(point p)
       {
             return point(x - p.x, y - p.y);
       }
};

bool eq(double a, double b)
{
     return fabs(a-b)<eps;
}
point inter(point p1, point p2, point p3, point p4)
{
      double A1 = p1.y - p2.y;
      double B1 = p2.x - p1.x;
      double C1 = -A1*p1.x - B1*p1.y;
      
      double A2 = p3.y - p4.y;
      double B2 = p4.x - p3.x;
      double C2 = -A2*p3.x - B2*p3.y;
      
      /*
      A1*x + B1*y + C1 = 0; *B2
      A2*x + B2*y + C2 = 0; *B1
      
      B2*A1*x + B2*B1*y + B2*C1 - B1*A2*x - B1*B2*y - B1*C2 = 0
      B2*A1*x + B2*C1 - B1*A2*x - B1*C2 = 0
      */
      if (B1*A2 - B2*A1 == 0) return point(-50000, 0);
      double x = (B2*C1 - B1*C2) / (B1*A2 - B2*A1);
      double y = (A2*C1 - A1*C2) / (A1*B2 - A2*B1);
      
      return point(x,  y);
}

double cross(point p1, point p2)
{
       return p1.x*p2.y - p1.y*p2.x;
}

double scalar(point p1, point p2)
{
       return p1.x*p2.x + p1.y*p2.y;
}

bool between(point p1, point p2, point p3, point P1, point P2)
{
     if (eq(cross(p2 - p1, p3 - p1), 0)) return 0;
     //cout << cross(p2 - p1, p3 - p1) << endl;
     if (cross(p2 - p1, p3 - p1) < 0) swap(p3, p2);
     if (cross(P2 - p1, P1 - p1) > 0) swap(P1, P2);
     double C1 = cross(p2 - p1, P1 - p1);
     double C2 = cross(p2 - p1, P2 - p1);
     double C3 = cross(p3 - p1, P1 - p1);
     double C4 = cross(p3 - p1, P2 - p1);
     
     //I
     if (!eq(C1, 0) && !eq(C3, 0) && !eq(C4, 0) && !eq(C2, 0))
     if ((C1 > 0 && C3 < 0) || (C2 > 0 && C4 < 0)) return 1;
     //
     if (eq(C1, 0) && eq(C3, 0)) return 0;
     if (eq(C2, 0) && eq(C4, 0)) return 0;
     
     //II
     if (!eq(C4, 0) && !eq(C2, 0))
     if (eq(C1, 0) && C4 > 0 && C2 > 0) return 1;
     if (!eq(C1, 0) && !eq(C3, 0))
     if (eq(C4, 0) && C1 < 0 && C3 < 0) return 1;
     
     //III
     if (eq(C1, 0) && scalar(P1 - p1, p2 - p1) > 0 &&
         eq(C4, 0) && scalar(P2 - p1, p3 - p1)) return 1;
     return 0;    
}
int N;
point P[100];
void solve()
{
     cin >> N;
     for (int i = 0; i < N; i++) cin >> P[i].x >> P[i].y;
     
     for (int i = 0; i < N; i++)
      for (int j = i + 1; j < N; j++)
      {
          point I = inter(P[i], P[(i+1)%N], P[j], P[(j+1)%N]);
          if (I.x < -30001 || I.x > 30001 || I.y < -30001 || I.y > 30001) continue;
          
          //cout << I.x << ":" << I.y << endl;
          bool flag = 1;
          for (int q1 = 0; q1 < N; q1++) if (flag)
           for (int q2 = 0; q2 < N; q2++) if (q1 != q2)
           {
               if (between(I, P[q1], P[(q1 + 1)%N], P[q2], P[(q2 + 1)%N]))
               {
            //        cout << q1 << " " << q2 << endl;
                    flag = 0; break; 
               }
           }
          if (flag) { cout << "YES" << endl; return; }
      }
     cout << "NO" << endl;
     return;
}

int main()
{
    int q;
    cin >> q;
    for (int i = 0; i < q; i++) solve();
    return 0;
}
