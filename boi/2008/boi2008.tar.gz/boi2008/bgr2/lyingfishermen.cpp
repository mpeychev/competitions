/*
TASK: lyingfishermen
LANG: C++
*/
#include <iostream>
using namespace std;

struct Vertex
{
       int u, next, cap;
       Vertex(int _b, int _cap, int _next):u(_b), cap(_cap), next(_next){}
       Vertex(){}
} nodes[60*60*60];

int in[100], out[100];
int table[100], cnt, N;

void add(int a, int b, int cap)
{
       nodes[cnt] = Vertex(b, cap, table[a]);
       table[a] = cnt++;
}

void reset()
{
     for (int v = 0; v < cnt; v += 2) nodes[v].cap = 1, nodes[v^1].cap = 0;
}

bool used[100];
bool DFS(int k)
{
     if (k == 2*N + 1) return 1;
     used[k] = 1;
     for (int v = table[k]; v != -1; v = nodes[v].next) 
      if (!used[nodes[v].u] && nodes[v].cap)
       if (DFS(nodes[v].u) == 1) { nodes[v].cap -= 1, nodes[v^1].cap += 1; return 1; }
     return 0;
}

int flood()
{
    for (int i = 0; i < N - 1; i++)
    {
        memset(used, 0, sizeof(used));
        if (DFS(0) == 0) return 0;
    }
    return 1;
}

int main()
{
    memset(table, -1, sizeof(table));
    cin >> N;
    for (int i = 1; i <= N; i++)
    {
        in[i] = cnt;
        add(0, i, 1);
        add(i, 0, 0);
        
        while (1)
        {
              int b; cin >> b; if (b == 0) break;
              add(i, N + b, 1);
              add(N + b, i, 0);
        }
        
        out[N + i] = cnt;
        add(N + i, 2*N + 1, 1);
        add(2*N + 1, N + i, 0);
    }
    
    bool flag = 0;
    for (int i = 1; i <= N; i++)
    {
        int f = 0;
        int fish = 0;
        for (int v = table[i]; nodes[v].next != -1; v = nodes[v].next)
        {
            reset();
            
            nodes[ in[i] ].cap = 0; nodes[ in[i]^1 ].cap = 0;
            nodes[v].cap = 0; nodes[v^1].cap = 0;
            nodes[ out[ nodes[v].u ] ].cap = 0; nodes[ out[ nodes[v].u ]^1 ].cap = 0;
            
            if (flood()) 
            { 
                //cout << i << " " << nodes[v].u - N << endl; 
                f++, fish = nodes[v].u - N; 
            }
        }
        
        if (f == 1) flag = 1, cout << i << " " << fish << endl;
    }
    if (!flag) cout << -1 << endl;
    return 0;    
}
