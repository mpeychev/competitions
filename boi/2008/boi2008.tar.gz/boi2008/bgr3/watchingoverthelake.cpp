/*
TASK: watchingoverthelake
LANG: C++
*/

#include <cstdio>
#include <cstdlib>
#include <cmath>

#define sign(a)			( (a) < 0 ? -1 : (a) > 0 )

struct point
{
	int x, y;
	point(){};
	point(int _x, int _y): x(_x), y(_y){};
};

inline point operator-(const point &a, const point &b)
{
	return point(a.x - b.x, a.y - b.y);
}

inline int cp(const point &a, const point &b)
{
	return a.x * b.y - a.y * b.x;
}

inline int cp(const point &a, const point &b, const point &c)
{
	return cp(b - a, c - a);
}

inline double dist(const point &a, const point &b)
{
	return sqrt( (a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y) );
}

point p[105];

inline bool intersect(int a, int b, int c, int d)
{
	return ( (sign(cp(p[a], p[b], p[c])) * sign(cp(p[a], p[b], p[d]))) == -1 ) 
		&& ( (sign(cp(p[c], p[d], p[a])) * sign(cp(p[c], p[d], p[b]))) == -1);
}

int T;
int N;
int main()
{
	scanf("%d", &T);
	for(int t = 0; t < T; t ++)
	{
		scanf("%d", &N);
		for(int i = 0; i < N; i ++)	scanf("%d %d", &p[i].x, &p[i].y);
		bool convex = 1;
		for(int i = 0; i + 2 < N; i ++)
			if( cp(p[i], p[i + 1], p[i + 2]) > 0 )
			{
				convex = 0;
				break;
			}
//		printf("%d\n", convex);
		if( convex == 1 )
		{
			printf("YES\n");
			continue;
		}
		p[N] = p[0];
		p[N + 1] = p[1];
		bool ok = 0;
		for(int i = 1; i <= N; i ++)
		{
			int c = cp(p[i - 1], p[i], p[i + 1]);
			bool cur = 1;
//			printf("i: %d c: %d\n", i, c);
			for(int j = 0; j < N; j ++)
			{
				int c1 = cp(p[i - 1], p[i], p[j]);
				int c2 = cp(p[i], p[i + 1], p[j]);
//				printf("i: %d j: %d c: %d c1: %d c2: %d\n", i, j, c, c1, c2);
				if( c > 0 )
					if( (c1 > 0) && (c2 > 0) )
					{
						cur = 0;
						break;
					}
				if( c < 0 )
					if( (c1 > 0) || (c2 > 0) )
					{
						cur = 0;
						break;
					}
			}
			if( cur == 0 )	continue;
//			printf("%d OK so far\n", i);
			double prev = 0;
			double p1 = cp(p[i], p[i + 1], p[i + 2]) / dist(p[i], p[i + 1]) / dist(p[i], p[i + 2]);
			bool fl = 0;
			if( prev > p1 )	fl = 1;
			for(int j = i + 2; j != i; j ++)
			{
				if( j == N + 2 )	j = 2;
				double curCP = cp(p[i], p[i + 1], p[j]) / dist(p[i], p[i + 1]) / dist(p[i], p[j]);
				if( fl && (curCP < prev) )
				{
					cur = 0;
					break;
				}
				if( (fl == 0) && (curCP > prev) )
				{
					cur = 0;
					break;
				}
				prev = curCP;
//				printf("i: %d j: %d cp: %lf\n", i, j, cp(p[i], p[i + 1], p[j]) / dist(p[i], p[i + 1]) / dist(p[i], p[j]));
			}
			
			if( cur == 1 )	ok = 1;
		}
		if(ok)	printf("YES\n");
		else	printf("NO\n");
	}
    return 0;
}
