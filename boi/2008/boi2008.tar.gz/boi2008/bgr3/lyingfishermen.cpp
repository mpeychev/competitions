/*
TASK: lyingfishermen
LANG: C++
*/

#include <cstdio>
#include <algorithm>

#define pii 		std :: pair<int, int>
#define mp			std :: make_pair

int n;
bool g[35][35];
int fish[35];
int man[35];
pii res[35];
int top = 0;
int main()
{
	scanf("%d", &n);
	for(int i = 0; i < n; i ++)
	{
		int p;
		scanf("%d", &p);
		do
		{
			p --;
			man[i] ++;
			fish[p] ++;
			g[i][p] = 1;
			scanf("%d", &p);
		}
		while( p != 0 );
	}
	
	while(1)
	{
		bool fl = 0;
		for(int i = 0; i < n; i ++)										// i - current fish
			if( fish[i] == 1 )
			{
				fl = 1;
				int j = 0;
				for(; j < n; j ++)	if( g[j][i] == 1 )	break;			// j - current man
				res[top ++] = mp(j, i);
//				printf("%d %d\n", j, i);
				fish[i] = 0;
				man[j] = 0;
				g[j][i] = 0;
				for(int k = 0; k < n; k ++)	if( g[j][k] )				// k - fishes that j claims
				{
					g[j][k] = 0;
					fish[k] --;
				}
				for(int k = 0; k < n; k ++)	if( g[k][i] )				// k - men that claim i
				{
					g[k][i] = 0;
					man[k] --;
				}
			}
		for(int i = 0; i < n; i ++)										// i - current man
			if( man[i] == 1 )
			{
				fl = 1;
				int j = 0;
				for(; j < n; j ++)	if( g[i][j] == 1 )	break;			// j - current fish
				res[top ++] = mp(i, j);
				man[i] = 0;
				fish[j] = 0;
				g[i][j] = 0;
				for(int k = 0; k < n; k ++)	if( g[i][k] )				// k - fishes that i claims
				{
					g[i][k] = 0;
					fish[k] --;
				}
				for(int k = 0; k < n; k ++)	if( g[k][j] )				// k - men that claim j
				{
					g[k][j] = 0;
					man[k] --;
				}
			}
		if( fl == 0 )	break;
	}
	if(top == 0)	printf("-1\n");
	else
	{
		std :: sort(res, res + top);
		for(int i = 0; i < top; i ++)	printf("%d %d\n", res[i].first + 1, res[i].second + 1);
	}
    return 0;
}
