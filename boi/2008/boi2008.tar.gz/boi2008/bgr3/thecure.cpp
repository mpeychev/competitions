/*
TASK: thecure
LANG: C++
*/

#include <cstdio>
#include <set>

#define pii		std :: pair<long long, int>
#define mp		std :: make_pair

int N, M;
int l[105];
int st[105][25];
int end[105][25];

inline bool mod(int a, int num, int& res)
{
	for(int i = 0; i < N; i ++)
	{
		if( (st[num][i] == 1) && ( (a & (1 << N - i - 1)) == 0 ) )
			return 0;
		if( (st[num][i] == -1) && ( (a & (1 << N - i - 1)) != 0 ) )
			return 0;
	}
	res = a;
	for(int i = 0; i < N; i ++)
	{
		if( end[num][i] == 1 )
			res |= (1 << N - i - 1);
		if( end[num][i] == -1 )
			res &= ~(1 << N - i - 1);
	}
	return 1;
}

unsigned long long dist[1048576 + 10];
std :: set<pii> q;
long long dijkstra(int st, int end)
{
	memset(dist, -1, sizeof(dist));
	dist[st] = 0;
	q.insert(mp(0, st));
	while( !q.empty() )
	{
		pii cur = *q.begin(); q.erase(q.begin());
		unsigned int num = cur.second;
		unsigned long long d = cur.first;
		if(num == end)	return d;
		int next;
		for(int i = 0; i < M; i ++)
		{
			if( mod(num, i, next) == 0 )	continue;
			if( (d + (long long)l[i] < dist[next]) )
			{
				if( dist[next] != -1 )	q.erase(mp(dist[next], next));
				dist[next] = d + (long long)l[i];
				q.insert(mp(dist[next], next));
			}
		}
	}
	return -1;
}

int main()
{
	scanf("%d %d", &N, &M);
	for(int i = 0; i < M; i ++)
	{
		scanf("%d", &l[i]);
		char c[25];
		scanf("%s", c);
		for(int j = 0; c[j]; j ++)
			st[i][j] = ( c[j] == '0' ) ? 0 : (c[j] == '+') ? 1 : -1;
		scanf("%s", c);
		for(int j = 0; c[j]; j ++)
			end[i][j] = ( c[j] == '0' ) ? 0 : (c[j] == '+') ? 1 : -1;
	}
	int res;
	printf("%lld\n", dijkstra((1 << N) - 1, 0));
    return 0;
}
