/*
TASK: braggingfishermen
LANG: C++
*/

#include <cstdio>
#include <vector>
#include <algorithm>

#define vi std :: vector<int>

int N, M;
int from[5005][105];
int dp[5005];
int top[5005];
int num[7];
int X[7];
vi w[10][150];
vi cur;

struct cmp
{
	inline bool operator() (const int &a, const int &b) const
	{
		return dp[a] < dp[b];
	}
};

int x = 0;
void gen(int pos, int left, int prev)
{
	if(left == 1)
	{
		w[pos][x] = cur;
		x ++;
		return;
	}
	for(int i = 0; i < top[left]; i ++)	if( from[left][i] < prev )
	{
		cur.push_back( from[left][i] );
		gen(pos, left / from[left][i], from[left][i]);
		cur.pop_back();
	}
}

bool used[105];
bool fl = 0;
void rec(int cur)
{
	if(fl)	return;
	if(cur == N)	
	{
		printf("YES\n");
		fl = 1;
		return;
	}
	for(int i = 0; i < X[cur]; i ++)
	{
		int to = w[cur][i].size();
		for(int j = 0; j < w[cur][i].size(); j ++)
			if( used[ w[cur][i][j] ] )	{ to = j; break;}
			else						used[ w[cur][i][j] ] = 1;
		if(to == w[cur][i].size())		rec(cur + 1);
		for(int j = 0; j < to; j ++)
			used[ w[cur][i][j] ] = 0;
	}
}

int main()
{
	dp[1] = 1;
	for(int i = 2; i <= 100; i ++)
		for(int j = 5000; j > 0; j --)
			if( (j * i <= 5000) && (dp[j] > 0) )
				from[j * i][ top[j * i] ++ ] = i, dp[j * i] += dp[j];
	scanf("%d %d", &N, &M);
	for(int j = 0; j < M; j ++)
	{
		for(int i = 0; i < N; i ++)
		{
			scanf("%d", &num[i]);
			if(num[i] > 5000)
			{
				printf("NO\n");
				goto next;
			}
		}
		std :: sort(num, num + N, cmp());
		for(int i = 0; i < N; i ++)
		{
			x = 0;
			gen(i, num[i], num[i] + 1);
			X[i] = x;
		}
		fl = 0;
		memset(used, 0, sizeof(used));
		rec(0);
		if(fl == 0)	printf("NO\n");
		next: ;
	}
    return 0;
}
