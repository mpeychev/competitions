/*
TASK: laundry
LANG: C++
*/

#include <cstdio>
#include <cstring>

#define abs(x) 					( (x) < 0 ? -(x) : (x) )
#define min(a, b) 				( (a) < (b) ? (a) : (b) )

int N, K;
int pos[205];
int pre[205][205];
unsigned int dp[205][35], NOT_SET;
int main()
{
    scanf("%d %d", &N, &K);
    for(int i = 1; i <= N; i ++) scanf("%d", &pos[i]);
    if(K >= N)
    {
		printf("0\n");
		return 0;
	}
    pos[0] = -200000;
    pos[N + 1] = 200000;
    for(int i = 1; i <= N; i ++)
    	for(int j = i; j <= N; j ++)
    		for(int k = i; k <= j; k ++)
	    		pre[i][j] += min( abs(pos[k] - pos[i - 1]), abs(pos[k] - pos[j + 1]) );
	memset(dp, -1, sizeof(dp)); NOT_SET = **dp;
	dp[0][0] = 0;
	for(int i = 1; i <= N; i ++)
		for(int j = 0; j < K; j ++)
			for(int k = 0; k < i; k ++)
				if( dp[k][j] != NOT_SET )
					dp[i][j + 1] = min( dp[i][j + 1], dp[k][j] + pre[k + 1][i - 1]);
	for(int i = 1; i < N; i ++)	if(dp[i][K] != NOT_SET)
		dp[N][K] = min(dp[N][K], dp[i][K] + pre[i + 1][N]);
	printf("%u\n", dp[N][K]);
    return 0;
}
