/*
TASK: weddingcakes
LANG: C++
*/

#include <cstdio>
#include <set>
#include <algorithm>

#define fx(it, a) for( typeof( (a).begin() ) it = (a).begin(); it != (a).end(); it ++)

struct piece
{
	int size, count;
	piece(){};
	piece(int _s, int _c): size(_s), count(_c){};
};

inline bool operator< (const piece &a, const piece &b)
{
	return a.count != b.count ? a.count > b.count : a.size < b.size;
}

int N;
int cnt[1000005];
int num[1000005];
bool used[10005];
int p[10005];
int st[10005];
int stTop = 0;
int top = 0;
int g, size;
int large, small;
std :: set<piece> s;
int main()
{
	scanf("%d", &N);
	for(int i = 0; i < N; i ++)
	{
		int p;
		scanf("%d", &p);
		cnt[p] ++;
	}
	for(int i = 1; i < 1000001; i ++)	if( cnt[i] )
	{
		s.insert(piece(i, cnt[i])); 
		if( cnt[i] > g )	g = cnt[i];
		num[i] = top;
		p[top ++] = i;
	}
//	fx(it, s) printf("%d %d\n", it->size, it -> count);
	large = N % g;
	small = g - large;
	size = N / g;
//	printf("groups: %d num small: %d num large: %d size: %d\n", g, small, large, size);
	printf("%d\n", g);
	for(int i = 0; i < g; i ++)
	{
		memset(used, 0, sizeof(used));
		std :: set<piece>:: iterator it = s.begin();
		int cur = 0;
		stTop = 0;
		while( (cur < size + (i >= small ? 1 : 0)) && (it != s.end()) )
		{
			int size = it->size, count = it->count;
			if( !used[ num[size] ] )
			{
				used[num[size]] = 1;
				cur ++;
				st[stTop ++] = size;
				it ++;
				s.erase(piece(size, count));
				if(count > 1)	s.insert(piece(size, count - 1));
			}
			else it ++;
		}
		std :: sort(st, st + stTop);
		for(int i = 0; i + 1 < stTop; i ++)	printf("%d ", st[i]);
		printf("%d\n", st[stTop - 1]);
	}
    return 0;
}
