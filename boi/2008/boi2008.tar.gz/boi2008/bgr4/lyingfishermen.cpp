
/*
TASK: lyingfishermen
LANG: C++
*/

#include <cstdio>
#include <vector>
#include <map>
using namespace std;

const int MAXN = 32;

vector <pair <int, int> > all;

int N;
int ok = 0;
int mark [MAXN];
bool g [MAXN][MAXN];
bool g2 [MAXN][MAXN];

int mask [MAXN];

void transpose ()
{
    ok ^= 1;
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            g2 [i][j] = g [j][i];
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < N; ++j)
            g [i][j] = g2 [i][j];
}
bool assignSingle ()
{
    for (int i = 0; i < N; ++i)
    {
        int c = 0, at = -1;
        for (int j = 0; j < N; ++j)
            if (g [i][j])
            {
                ++c;
                at = j;
            }
        if (c == 1)
        {
            if (!ok)
                all.push_back (make_pair (i, at));
            else
                all.push_back (make_pair (at, i));
                
            for (int v = 0; v < N; ++v)
            {
                g [i][v] = false;
                g [v][at] = false;
            }
            return true;
        }
    }
    return false;
}
int main ()
{
    scanf ("%d", &N);
    
    for (int i = 0; i < N; ++i)
    {
        int x;
        scanf ("%d", &x);
        while (x != 0)
        {
            g [i][x - 1] = true;
            scanf ("%d", &x);
        }
    }
    
    memset (mark, -1, sizeof (mark));
    int cnt = 0;
    while (cnt < 31)
    {
        int noSteps = 0;
        while (noSteps < 31)
        {
            if (assignSingle ()) {noSteps = 0; cnt = 0; continue;}
            transpose ();
            ++noSteps;
        }
        
        map <int, int> mapper;
        map <int, int>::iterator it;
        memset (mask, 0, sizeof (mask));
        for (int i = 0; i < N; ++i)
        {
            for (int j = 0; j < N; ++j)
                if (g [i][j])
                    mask [i] |= (1 << j);
            mapper [mask [i]]++;
        }
        
        for (it = mapper.begin (); it != mapper.end (); ++it)
            if (__builtin_popcount (it -> first) == it -> second)
            {
                for (int i = 0; i < N; ++i)
                    if (mask [i] == it -> first)
                    {
                        for (int j = 0; j < N; ++j)
                            g [i][j] = false;
                    }
                for (int i = 0; i < N; ++i)
                    if (it -> first & (1 << i))
                    {
                        for (int j = 0; j < N; ++j)
                            g [j][i] = false;
                    }
                cnt = 0;
                break;
            }
        ++cnt;
    }
    
    vector <int> res (N, -1);
    for (int i = 0; i < (int) all.size (); ++i)
        res [all [i].first] = all [i].second;
    
    if ((int) all.size () == 0)
    {
        printf ("-1\n");
    }
    else
    {
        for (int i = 0; i < N; ++i)
            if (res [i] != -1)
                printf ("%d %d\n", i + 1, res [i] + 1);
    }
    
    return 0;
}
