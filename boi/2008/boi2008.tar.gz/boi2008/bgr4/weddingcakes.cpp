
/*
TASK: weddingcakes
LANG: C++
*/

#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 16384;

int N;
int h [MAXN];
int ch [MAXN];

inline bool cmp (vector <int> &a, vector <int> &b)
{
    return a.size () < b.size ();
}

void read ()
{
    scanf ("%d", &N);
    for (int i = 0; i < N; ++i)
        scanf ("%d", &h [i]);
}
void solve ()
{
    sort (h, h + N);
    
    // O (n ^ 2): Finds the minimum number of cakes!
    //
    int minAm = 0;
    memset (ch, 0x3f, sizeof (ch));
    for (int i = N - 1; i >= 0; --i)
        for (int j = 0; true; ++j)
            if (ch [j] > h [i])
            {
                ch [j] = h [i];
                minAm = max (minAm, j + 1);
                break;
            }
    //
    
    vector <vector <int> > cake (minAm, vector <int> (1, 2000000));
    
    // O (n ^ 2): Finds the best splitting of the layers!
    //
    for (int j = N - 1; j >= 0; --j)
    {
        int at = -1;
        for (int i = 0; i < minAm; ++i)
            if (cake [i].back () > h [j])
            {
                if (at == -1) 
                    at = i;
                else 
                    if (cake [i].size () < cake [at].size ())
                        at = i;
                    else
                        if (cake [i].size () == cake [at].size () && cake [i].back () > cake [at].back ())
                            at = i;
            }
        cake [at].push_back (h [j]);
    }
    //
    
    printf ("%d\n", (int) cake.size ());
    sort (cake.begin (), cake.end ());
    for (int i = 0; i < (int) cake.size (); ++i)
    {
        bool space = false;
        for (int j = (int) cake [i].size () - 1; j > 0; --j)
        {
            if (space)
                printf (" ");
            space = true;
            printf ("%d", cake [i][j]);
        }
        puts ("");
    }
}
int main ()
{
    read ();
    solve ();
    return 0;
}
