
/*
TASK: laundry
LANG: C++
*/

#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;

//#define abs(x) ((x) < 0 ? (-(x)) : (x))
//#define min(a, b) ((a) < (b) ? (a) : (b))

const int MAXN = 256;
const int MAXK = 32;

int N, K;
int h [MAXN];
int after [MAXN];
int add [MAXN][MAXN];
int best [MAXK][MAXN];

void read ()
{
    scanf ("%d %d", &N, &K);
    for (int i = 0; i < N; ++i)
        scanf ("%d", &h [i]);
}
int solve ()
{
    memset (after, 0, sizeof (after));
    memset (best, 0x3f, sizeof (best));
    
    for (int i = 0; i < N; ++i)
    {
        best [K - 1][i] = 0;
        for (int j = 0; j <= i; ++j)
            best [K - 1][i] += abs (h [i] - h [j]);
        after [i] = 0;
        for (int j = i; j < N; ++j)
            after [i] += abs (h [j] - h [i]);
    }
    
    memset (add, 0x3f, sizeof (add));
    for (int i = 0; i < N; ++i)
        for (int j = i; j < N; ++j)
        {
            add [i][j] = 0;
            for (int k = i; k <= j; ++k)
                add [i][j] += min (abs (h [i] - h [k]), abs (h [j] - h [k]));
        }
    
    for (int i = K - 1; i > 0; --i)
        for (int j = 0; j < N; ++j)
            for (int k = j; k < N; ++k)
            {
                best [i - 1][k] = min (best [i - 1][k], best [i][j] + add [j][k]);
            }
    int res = 0x3f3f3f3f;
    for (int i = 0; i < N; ++i)
        res = min (res, best [0][i] + after [i]);
    return res;
}
int main ()
{
    read ();
    printf ("%d\n", solve ());
    return 0;
}
