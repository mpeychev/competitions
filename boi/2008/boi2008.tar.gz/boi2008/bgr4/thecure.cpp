
/*
TASK: thecure
LANG: C++
*/

#include <queue>
#include <string>
#include <iostream>
#include <algorithm>
using namespace std;

struct state
{
    long long cost;
    int node;
    
    inline bool operator < (const state &rhs) const
    {
        return cost > rhs.cost;
    }
};

const int MAXN = 21;
const int MAXM = 128;
long long INF;

int N, M;
int cost [MAXM];
int c_on [MAXM], c_off [MAXM];
int r_on [MAXM], r_off [MAXM];
long long best [1 << MAXN];

int parse (string str, char ch)
{
    int mask = 0;
    for (int i = 0; i < (int) str.size (); ++i)
    {
        mask <<= 1;
        if (str [i] == ch)
            mask |= 1;
    }
    return mask;
}
void read ()
{
    cin >> N >> M;
    for (int i = 0; i < M; ++i)
    {
        string s, t;
        cin >> cost [i] >> s >> t;
        c_on [i] = parse (s, '+');
        c_off [i] = parse (s, '-');
        r_on [i] = parse (t, '+');
        r_off [i] = parse (t, '-');
    }
}
long long solve ()
{
    memset (best, 0x3f, sizeof (best));
    INF = best [0];
    best [(1 << N) - 1] = 0;
    priority_queue <state> pq;
    pq.push ((state) {0, (1 << N) - 1});
   
    int nxt;
    state t;
    while (!pq.empty ())
    {
        t = pq.top ();
        pq.pop ();
        if (best [t.node] < t.cost)
            continue;
        for (int j = 0; j < M; ++j)
            if ((t.node & c_on [j]) == c_on [j])
                if ((t.node & c_off [j]) == 0)
                {
                    nxt = t.node | r_on [j];
                    nxt = nxt & ~(r_off [j]);
                    if (best [nxt] > t.cost + cost [j])
                    {
                        best [nxt] = t.cost + cost [j];
                        pq.push ((state) {best [nxt], nxt});
                    }
                }
    }
    return (best [0] >= INF ? -1 : best [0]);
}
int main ()
{
    read ();
    cout << solve () << endl;
    return 0;
}
