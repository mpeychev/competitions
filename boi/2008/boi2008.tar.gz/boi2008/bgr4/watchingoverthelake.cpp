
/*
TASK: watchingoverthelake
LANG: C++
*/

#include <iostream>
using namespace std;

const int MAXN = 128;

struct point
{
    long long x, y;
};

inline long long cross (point &a, point &b, point &c)
{
    return a.x * (b.y - c.y) + b.x * (c.y - a.y) + c.x * (a.y - b.y);
}

int N;
point p [MAXN];
int am [MAXN][MAXN][MAXN];
long long area [MAXN][MAXN][MAXN];

int main ()
{
    int cases;
    cin >> cases;
    for (int c = 0; c < cases; ++c)
    {
        memset (am, 0, sizeof (am));
        memset (area, 0, sizeof (area));
        
        cin >> N;
        for (int i = 0; i < N; ++i)
            cin >> p [i].x >> p [i].y;
        
        #define myabs(x) ((x) > 0 ? (x) : (-(x)))
        
        for (int i = 0; i < N; ++i)
            for (int j = 0; j < N; ++j)
                for (int k = 0; k < N; ++k)
                    area [i][j][k] = myabs (cross (p [i], p [j], p [k]));
        for (int i = 0; i < N; ++i)
            for (int j = 0; j < N; ++j)
                for (int k = 0; k < N; ++k)
                {
                    if (i <= j && j <= k)
                    {
                        for (int z = 0; z < N; ++z)
                            if (i != z && j != z && k != z)
                                if (area [i][j][z] && area [i][k][z] && area [j][k][z])
                                    if (area [i][j][k] == area [i][j][z] + area [i][k][z] + area [j][k][z])
                                        ++am [i][j][k];
                        am [i][k][j] = am [k][i][j] = am [k][j][i] = 
                            am [j][i][k] = am [j][k][i] = am [i][j][k];
                    }
                }
        
        bool ok = false;
        for (int i = 0; i < N; ++i)
        {
            bool now = true;
            for (int j = 0; j < N; ++j)
                if (am [i][(i + j + 1) % N][(i + j + 2) % N] || 
                    cross (p [i], p [(i + j + 1) % N], p [(i + j + 2) % N]) > 0)
                    now = false;
            if (now)
                ok = true;
        }
        printf ("%s\n", (ok ? "YES" : "NO"));
    }
    return 0;
}
