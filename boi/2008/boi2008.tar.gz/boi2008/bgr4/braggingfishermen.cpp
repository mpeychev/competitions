
/*
TASK: braggingfishermen
LANG: C++
*/

#include <cstdlib>
#include <cstdio>
#include <vector>
#include <ext/hash_set>
using namespace std;

const int MAX = 5005;

int N;
int big [MAX];
vector <int> scores;

struct cmp
{
    inline size_t operator () (const vector <int> &v) const
    {
        size_t h = 0;
        for (int i = 0; i < (int) v.size (); ++i)
            h = h * 3137 + v [i];
        return h;
    }
};

bool randomised ()
{
    vector <int> cur = scores;
    for (int j = 100; j >= 2; --j)
    {
        vector <int> all;
        for (int i = 0; i < N; ++i)
            if (cur [i] % j == 0)
                all.push_back (i);
        if ((int) all.size () == 0)
            continue;
        
        cur [all [rand () % all.size ()]] /= j;
    }
    return cur == vector <int> (N, 1);
}

bool solve ()
{
    __gnu_cxx::hash_set <vector <int>, cmp> all [2];
    __gnu_cxx::hash_set <vector <int>, cmp> :: iterator it;
    all [0].insert (scores);
    
    for (int i = 0; i < 10000; ++i)
        if (randomised ())
        {
            return true;
        }
    
    for (int j = 100; j >= 2; --j)
    {
        all [~j & 1].clear ();
        for (it = all [j & 1].begin (); it != all [j & 1].end (); ++it)
        {
            bool any = false;
            for (int i = 0; i < N; ++i)
                if (big [(*it) [i]] > j)
                    any = true;
            if (any)
            {
                continue;
            }
            for (int i = 0; i < N; ++i)
                if ((*it) [i] % j == 0)
                {
                    vector <int> nxt = *it;
                    nxt [i] /= j;
                    all [~j & 1].insert (nxt);
                }
            all [~j & 1].insert (*it);
        }
    }
    vector <int> target (N, 1);
    return all [0].count (target) || all [1].count (target);
}
int main ()
{
    big [1] = 1;
    for (int i = 2; i <= 5000; ++i)
    {
        int z = i;
        for (int j = 2; j * j <= z; ++j)
            while (z % j == 0)
            {
                z /= j;
                big [i] = max (big [i], j);
            }
        if (z != 1)
            big [i] = max (big [i], z);
    }
    
    
    int cases;
    scanf ("%d", &N);
    scanf ("%d", &cases);
    for (int i = 0; i < cases; ++i)
    {
        scores.clear ();
        scores = vector <int> (N, -1);
        for (int j = 0; j < N; ++j)
            scanf ("%d", &scores [j]);
        printf ("%s\n", (solve () ? "YES" : "NO"));
    }
    return 0;
}
