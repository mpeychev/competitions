/*
TASK: lyingfishermen
LANG: C++
*/
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 1 << 7;

struct edge {
	int to;
	int cap;
	int revy;
	int isrev;
	
	edge () {}
	edge ( int _to , int _cap , int _isrev ) {
		to = _to;
		cap = _cap;
		isrev = _isrev;
	}
};

int n;
int ans[MAXN];

int v;
vector < edge > a[MAXN];
int source , sink;
int d[MAXN];
int used[MAXN];

void make_edge ( int q , int w ) {
	int s1 = (int)a[q].size();
	int s2 = (int)a[w].size();
	
	a[q].push_back ( edge ( w , 1 , 0 ) );
	a[w].push_back ( edge ( q , 0 , 1 ) );
	
	a[q][s1].revy = s2;
	a[w][s2].revy = s1;
}

void read() {
	int i;
	int x;
	
	scanf ("%d",&n);
	
	source = 2 * n + 1;
	sink = 2 * n + 2;
	v = 2 * n + 2;

	for (i=1;i<=n;i++) {
		make_edge ( source , i );
		make_edge ( n + i , sink );
	}
	
	for (i=1;i<=n;i++)
		while ( scanf ("%d",&x) , x ) 
			make_edge ( i , n + x );
}

int bfs() {
	static int q[MAXN];
	int i , j;
	int sz;
	
	for (i=1;i<=v;i++) {
		used[i] = 0;
		d[i] = -1;
	}
	
	q[sz = 0] = sink;
	d[sink] = 0;
	
	for (i=0;i<=sz;i++)
		for (j=0;j<(int)a[ q[i] ].size();j++)
			if ( d[ a[ q[i] ][j].to ] == -1 && a[ a[ q[i] ][j].to ][ a[ q[i] ][j].revy ].cap ) {
					d[ a[ q[i] ][j].to ] = d[ q[i] ] + 1;
					q[ ++ sz ] = a[ q[i] ][j].to;
				}
				
	return d[source] != -1;
}

int dfs ( int node ) {
	if ( node == sink ) return 1;
	used[node] = 1;
	int i;
	
	for (i=0;i<(int)a[node].size();i++)
		if ( !used[ a[node][i].to ] && d[ a[node][i].to ] + 1 == d[node] && a[node][i].cap )
				if ( dfs ( a[node][i].to ) ) {
					-- a[node][i].cap;
					++ a[ a[node][i].to ][ a[node][i].revy ].cap;
					return 1;
				}
			
	return 0;				
}

void fix_edge ( int q , int w , int s , int t ) {
	a[q][w].cap = s;
	a[ a[q][w].to ][ a[q][w].revy ].cap = t;
}

void solve() {
	int i , j , k , d;
	int maxflow;
	int fnd = 0;
	
	for (i=1;i<=n;i++) {
		for (k=1;k<=v;k++)
			for (d=0;d<(int)a[k].size();d++)
				if ( !a[k][d].isrev )
					fix_edge ( k , d , 1 , 0 );
						
		fix_edge ( i , 1 , 0 , 0 );
			
		maxflow = 0;
		while ( bfs() ) 
			while ( dfs ( source ) )
				++ maxflow;
					
		if ( maxflow != n ) {
			ans[i] = a[i][1].to - n;
			continue;
		}
		
		for (j=2;j<(int)a[i].size();j++)
			if ( !a[i][j].isrev && !a[i][j].cap )
				break;
				
		ans[i] = a[i][j].to - n;
		
		fix_edge ( i , 1 , 1 , 0 );
		fix_edge ( source , i - 1 , 1 , 0 );
		fix_edge ( i , j , 0 , 0 );
		fix_edge ( a[i][j].to , 0 , 1 , 0 );
		-- maxflow;
		
		while ( bfs() )
			while ( dfs ( source ) )
				++ maxflow;
				
		if ( maxflow == n )
			ans[i] = -1;
	}
		
	for (i=1;i<=n;i++)
		if ( ans[i] > 0 ) {
			printf ("%d %d\n",i,ans[i]);
			fnd = 1;
		}
		
	if ( !fnd ) printf ("-1\n");
}

int main() {
	read();
	solve();
	
	return 0;
}
