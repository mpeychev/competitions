/*
TASK: laundry
LANG: C++
*/
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 1 << 8;
const int MAXK = 1 << 5;

int n , k;
int a[MAXN];

int s1[MAXN];
int s2[MAXN];

int dp[MAXN][MAXK];

void read() {
	int i;
	
	scanf ("%d%d",&n,&k);
	for (i=1;i<=n;i++)
		scanf ("%d",&a[i]);
}

void init() {
	int i;
	
	for (i=1;i<=n;i++)
		s1[i] = s1[i - 1] + a[i];
	for (i=n;i>=1;i--)
		s2[i] = s2[i + 1] + a[n] - a[i];	
}

int go ( int p , int k ) {
	if ( p == n ) return 0;
	if ( !k ) return s1[n] - s1[p] - (n - p) * a[p];
	if ( dp[p][k] != -1 ) return dp[p][k];
	int i , j;
	int x;
	int ans = 1 << 30;
	
	if ( !p ) {
		for (i=1;i<=n;i++)
			ans = min ( ans , go ( i , k - 1 ) + s2[1] - s2[i] - (i - 1) * (a[n] - a[i]) );
	} else {
		j = p;
		for (i=p + 1;i<=n;i++) {
			while ( a[j + 1] - a[p] < a[i] - a[j + 1] ) ++ j;
			
			x = go ( i , k - 1 );
			x += s2[j + 1] - s2[i] - (i - j - 1) * (a[n] - a[i]);
			x += s1[j] - s1[p] - (j - p) * a[p];
			
			ans = min ( ans , x );
		}
	}
	
	return dp[p][k] = ans;
}

void solve() {
	memset ( dp , -1 , sizeof dp );
	printf ( "%d\n" , go ( 0 , k ) );
}

int main() {
	read();
	init();
	solve();
	
	return 0;
}
