/*
TASK: braggingfishermen
LANG: C++
*/
#include <cstdio>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 1 << 3;

int n , m;
int a[MAXN];
int used[128];
int ans;
vector < vector < int > > y;

void read() {
	int i;
	
	for (i=1;i<=n;i++)
		scanf ("%d",&a[i]);
}

void rec () {
	int i , j , k , d;
	int cnt;
	int x;
	
	for (i=100;i>=1;i--) {
		cnt = 0;
		
		/*
		for (j=0;j<(int)y.size();j++)
			for (k=0;k<(int)y[j].size();k++)
				cnt += (y[j][k] == i);
		*/
		cnt = used[i];
				
		if ( cnt >= 2 ) {
			if ( i > 50 ) 
				return ;
				
			cnt = 0;
				
			for (j=0;j<(int)y.size();j++) {
				for (k=0;k<(int)y[j].size();k++)
					if ( y[j][k] == i ) break;
					
				if ( k == (int)y[j].size() ) continue;
				
				++ cnt;
				for (d=0;d<(int)y[j].size();d++)
					if ( d != k && y[j][k] * y[j][d] <= 100 ) {
						
						-- used[ y[j][d] ];
						-- used[ y[j][k] ];
						++ used[ y[j][d] * y[j][k] ];
						
						x = y[j][d];
						y[j][k] = y[j][k] * y[j][d];
						y[j].erase ( y[j].begin() + d );
						
						rec ();

						y[j].insert ( y[j].begin() + d , x );
						y[j][k] /= x;
						
						++ used[ y[j][d] ];
						++ used[ y[j][k] ];
						-- used[ y[j][d] * y[j][k] ];
						
						if ( ans ) return ;
					}
				
				if ( cnt == 2 ) break;
			}
			
			return ;
		}
	}
	
	ans = 1;
}

void solve() {
	int i , j;
	vector < vector < int > > f;
	vector < int > t;
	
	memset ( used , 0 , sizeof used );
	
	for (i=1;i<=n;i++) {
		t.clear();
		
		if ( a[i] == 1 ) t.push_back ( a[i] );
		
		for (j=2;j<a[i];j++)
			if ( !(a[i] % j) ) {
				a[i] /= j;
				t.push_back ( j );
			}
			
		if ( a[i] > 1 ) t.push_back ( a[i] );
		
		for (j=0;j<(int)t.size();j++) {
			if ( t[j] > 100 ) {
				printf ("NO\n");
				return ;
			}
			
			if ( t[j] > 50 ) {
				++ used[ t[j] ];
				t.erase ( t.begin() + j );
				-- j;
			}
		}
		
		f.push_back ( t );
	}
	
	for (i=51;i<=100;i++) {
		if ( used[i] >= 2 ) {
			printf ("NO\n");
			return ;
		}
		
		used[i] = 0;
	}
/*
	for (i=0;i<(int)f.size();i++) {
		for (j=0;j<(int)f[i].size();j++) 	
			printf ("%d ",f[i][j]);
		printf ("\n");
	}
	printf ("\n");
	*/	
	
	for (i=0;i<(int)f.size();i++)
		for (j=0;j<(int)f[i].size();j++)
			++ used[ f[i][j] ];

	ans = 0;	
	y = f;
	rec ();
	
	if ( ans ) 
		printf ("YES\n");
	else
		printf ("NO\n");
}

int main() {
	scanf ("%d%d",&n,&m);
	
	while ( m -- ) {
		read();
		solve();
		
//		printf ("%lf\n",(double)clock()/(double)CLOCKS_PER_SEC);
	}
		
	return 0;
}
