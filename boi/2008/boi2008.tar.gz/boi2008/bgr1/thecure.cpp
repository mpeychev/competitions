/*
TASK: thecure
LANG: C++
*/
#include <cstdio>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;

const int MAXN = 20;
const int MAXM = 1 << 7;

struct el {
	int node , cost;
	
	el () {}
	el ( int _node , int _cost ) : node(_node) , cost(_cost) {}
};

struct Cmp {
	bool operator () ( el a , el b ) {
		return a.cost > b.cost;
	}
};

int n , m;
char q[MAXM][MAXN + 12];
char w[MAXM][MAXN + 12];
int t[MAXM];

priority_queue < el , vector < el > , Cmp > pq;
int d[1 << MAXN];

void read() {
	int i;
	
	scanf ("%d%d",&n,&m);
	
	for (i=1;i<=m;i++)
		scanf ("%d%s%s",&t[i],q[i],w[i]);
}

inline int can ( int node , int j ) {
	int i;
	
	for (i=0;i<n;i++) {
		if ( q[j][i] != '0' && ((q[j][i] == '+') ^ !!(node & (1 << i))) )
			return -1;
		
		if ( w[j][i] == '-' )
			node &= ~(1 << i);
		if ( w[j][i] == '+' )
			node |= 1 << i;
	}
	
	return node;
}

inline void psh ( int node , int cost ) {
	if ( d[node] > cost ) {
		d[node] = cost;
		pq.push ( el ( node , cost ) );
	}
}

void solve() {
	int i;
	int x;
	el r;
		
	for (i=0;i<(1 << n);i++)
		d[i] = 1 << 30;
	
	psh ( (1 << n) - 1 , 0 );
	
	while ( !pq.empty() ) {
		r = pq.top(); pq.pop();
		
		if ( !r.node ) {
			printf ("%d\n",r.cost);
			return ;
		}
		
		if ( d[ r.node ] < r.cost ) continue;
		
		for (i=1;i<=m;i++) {
			x = can ( r.node , i );
			
			if ( x != -1 )
				psh ( x , r.cost + t[i] );
		}
	}
	
	printf ("-1\n");
}

int main() {
	read();
	solve();
	
	return 0;
}
