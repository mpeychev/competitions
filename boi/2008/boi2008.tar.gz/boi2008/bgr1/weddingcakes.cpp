/*
TASK: weddingcakes
LANG: C++
*/
#include <cstdio>
#include <algorithm>
using namespace std;

const int MAXN = 1 << 14;

int n;
int a[MAXN];

void read() {
	int i;
	
	scanf ("%d",&n);
	for (i=1;i<=n;i++)
		scanf ("%d",&a[i]);
}

void solve() {
	int i , j;
	int ans = 0;
	
	sort ( a + 1 , a + n + 1 );
	
	for (i=j=1;i<=n;i++) {
		while ( j <= n && a[i] == a[j] ) ++ j;
		
		if ( j - i > ans )
			ans = j - i;
	}
	
	printf ("%d\n",ans);
	for (i=1;i<=ans;i++) {
		printf ("%d",a[i]);
		
		for (j=i + ans;j<=n;j+=ans)
			printf (" %d",a[j]);
		printf ("\n");
	}
}

int main() {
	read();
	solve();
	
	return 0;
}
