/*
TASK: watchingoverthelake
LANG: C++
*/
#include <cstdio>
#include <cmath>

const int MAXN = 1 << 7;

struct point {
	int x , y;
	
	void read() {
		scanf ("%d%d",&x,&y);
	}
};

int n;
point a[MAXN];

void read() {
	int i;
	
	scanf ("%d",&n);
	for (i=1;i<=n;i++)
		a[i].read();
	a[n + 1] = a[1];
}

double cross ( double x1 , double y1 , double x2 , double y2 , double x3 , double y3 ) {
	return (x2 - x1) * (y3 - y1) - (x3 - x1) * (y2 - y1);
}

int check ( double x , double y ) {
	int i;
	
	for (i=1;i<=n;i++) 
		if ( cross ( a[i].x , a[i].y , a[i + 1].x , a[i + 1].y , x , y ) > 1e-9 )
			return 0;
			
	return 1;
}

int solve() {
	int i , j;
	double x , y;
	
	for (i=1;i<=n;i++)
		if ( check ( a[i].x , a[i].y ) )
			return 1;
			
	for (i=1;i<=n;i++)
		for (j=i + 1;j<=n;j++) {
			x = cross( a[i].x , a[i].y , a[i + 1].x , a[i + 1].y , a[j].x , a[j].y);
			y = cross( a[i].x , a[i].y , a[i + 1].x , a[i + 1].y , a[j + 1].x , a[j + 1].y);
	
			if ( fabs ( x ) < 1e-9 && fabs ( y ) < 1e-9 ) continue;
			
			x = cross ( a[i].x , a[i].y , a[j].x , a[j].y , a[j + 1].x , a[j + 1].y );
			y = cross ( a[i].x , a[i].y , a[j].x , a[j].y , a[i + 1].x , a[i + 1].y ) 
			+ cross ( a[i].x , a[i].y , a[i + 1].x , a[i + 1].y , a[j + 1].x , a[j + 1].y );
			
			if ( fabs ( y ) < 1e-9 ) continue;

		/*	printf ("%d %d -> %d %d  |  %d %d -> %d %d     %lf %lf\n",
			a[i].x,a[i].y,a[i+1].x,a[i+1].y,a[j].x,a[j].y,a[j+1].x,a[j+1].y,
			a[i].x + (x / y) * ((double)a[i + 1].x - a[i].x),
			a[i].y + (x / y) * ((double)a[i + 1].y - a[i].y));
*/
			if ( check ( a[i].x + (x / y) * ((double)a[i + 1].x - a[i].x) ,
						 a[i].y + (x / y) * ((double)a[i + 1].y - a[i].y) ) )
					return 1;
		}
			
	return 0;
}

int main() {
	int k;
	
	scanf ("%d",&k);
	
	while ( k -- ) {
		read();
		
		if ( solve() )
			printf ("YES\n");
		else
			printf ("NO\n");
	}
	
	return 0;
}
